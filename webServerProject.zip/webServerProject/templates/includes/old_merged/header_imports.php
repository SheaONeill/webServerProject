<?php
/**
 * Created by PhpStorm.
 * User: B00084432
 * Date: 15/03/2016
 * Time: 14:46
 */
?>

    <style> @import "/css/layout.css";@import "/css/nav.css";@import "/css/stylesheet.css";@import "/css/media_queries.css";</style><!-- link to stylesheets -->
    <link rel="icon" type="image/png" href="/images/icons/favicon.ico"><!-- bookmark icon -->
</head><!-- close head tag -->
