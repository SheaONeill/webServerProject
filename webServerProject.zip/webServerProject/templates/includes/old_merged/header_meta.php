<?php
/**
 * Created by PhpStorm.
 * User: B00084432
 * Date: 15/03/2016
 * Time: 14:45
 */
?>

    <meta name="keywords" content="Stjosephschurcheastwall, st josephs church east wall, St. Joseph's Parish, Parish, Religion, Faith, East Wall, Dublin, Church, school, Patron" /><!-- keywords -->
    <meta name="author" content="Stjosephschurcheastwall" /><!-- author name of parish -->
    <meta content="width=device-width,initial-scale=1.0" name="viewport"><!-- configuring the viewport for mobiles and smartphones -->
