<?php
/**
 * Created by PhpStorm.
 * User: B00084432
 * Date: 15/03/2016
 * Time: 14:43
 */
?>
<!doctype html><!-- define the document type!! -->
<html lang="en"><!-- begin html and define language -->
<head><!-- begin Head tag -->
    <meta charset="utf-8" /><!-- define the character set  -->
    <title><?= $pageTitle ?></title><!-- title of webpage -->