<?php
/**
 * Created by PhpStorm.
 * User: B00084432
 * Date: 15/03/2016
 * Time: 15:04
 */
?>

<div class="media_logo_wrapper"><!-- begin media_logo_wrapper -->
    <!-- logo -->
    <div class="header_logo"><!-- begin header logo -->
        <a href="http://www.shea.ie"><img alt="" src="/images/logo/christian_fish_cross.png"></a><!-- close logo image and link -->
    </div><!-- close header logo -->
    <!-- heading -->
    <div class="header_title"><h1>ST. Joseph's Parish Church, East Wall</h1></div><!-- close header heading -->
    <!-- social media -->
    <div class="social_media"><!-- begin social media links -->
        <ul><!-- begin unordered social media link list -->
            <li><a href="#" target="_blank"><img src="/images/icons/facebook1.png" alt="Facebook St. Joseph's Parish" title="Facebook St. Joseph's Parish"></a></li><!-- social media link list item -->
            <li><a href="#" target="_blank"><img src="/images/icons/twitter1.png" alt="Tweet St. Joseph's Parish" title="Tweet St. Joseph's Parish"></a></li><!-- social media link list item -->
            <li><a href="#" target="_blank"><img src="/images/icons/googleplus.png" alt="St. Joseph's Parish on Google+" title="St. Joseph's Parish on Google+"></a></li><!-- social media link list item -->
            <li><a href="#" target="_blank"><img src="/images/icons/youtube1.png" alt="St. Joseph's Parish on You Tube" title="St. Joseph's Parish on You Tube"></a></li><!-- social media link list item -->
        </ul><!-- close social media link list -->
    </div><!-- close social media links -->
</div><!-- media_logo_wrapper -->
