<?php
/**
 * Created by PhpStorm.
 * User: sheaoneill
 * Date: 24/03/16
 * Time: 09:47
 */
?>

<!--<H1>Details for record with id : <?/*= $module->getId() */?></H1>-->

<h2>Id</h2>
<p><?= $module->getId() ?></p>

<h2>Heading </h2>
<p><?= $module->getHeading() ?></p>

<h2>Sub Heading 1 </h2>
<p><?= $module->getSubheading1() ?></p>

<h2>Sub Heading 2 </h2>
<p><?= $module->getSubheading2() ?></p>

<h2>Paragraph </h2>
<p><?= $module->getParagraph() ?></p>
    