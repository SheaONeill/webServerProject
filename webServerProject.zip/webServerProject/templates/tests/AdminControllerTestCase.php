<?php
/**
 * Created by PhpStorm.
 * User: B00084432
 * Date: 20/04/2016
 * Time: 16:38
 */

namespace StJosephsChurchEastWallTest;

class AdminControllerTestCase
{
}
